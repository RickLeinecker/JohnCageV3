const express = require('express');
const bodyParser = require('body-parser');
const ms = require('mediaserver');
const http = require('http');
const app = express();
const cors = require('cors');
const APIPort = 5000;
const socketPort = 5001;

//MySQL integration
const mysql = require('mysql2');
const pool = mysql.createPool({
  host: 'localhost',
  user: 'New',
  database: 'JCT',
  password: 'MyN3wP4ssw0rd'
});

//Export express object required for Jest unit testing.
module.exports = app;

//Required for socket testing using socket.io
const socketio = require("socket.io");
const socketServer = http.createServer(app);
const io = socketio(socketServer, { cors: { origin: "http://localhost:3000" } });

io.on('connect', (socket) => {
  console.log('a user connected');

  socket.emit('receiveGreet', { data: 'This message from socketServer' }, (error) => {
    console.log('error::', error)
  })

  socket.on('disconnect', () => {
    console.log('user disconnected')
  })

  socket.on('input', ({ data }) => {
    console.log(data);
  })
});

//Express app configuration
app.use(cors());
app.use(bodyParser.json());
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );
  res.setHeader(
    'Access-Control-Allow-Methods',
    'GET, POST, PATCH, DELETE, OPTIONS'
  );
  next();
});

//Express app API
app.get('/', (req, res) => {
  res.send('Hello World');
});

app.post('/api/searchSongs', async (req, res, next) => {
  var searchString = req.query["search"];
  var sqlSearch;
  if (searchString) {
    sqlSearch = "SELECT ID, Title FROM Recordings WHERE Title like '%" + searchString + "%'";
  }
  else {
    sqlSearch = "SELECT ID, Title FROM Recordings WHERE Title like '%%'";
  }

  pool.execute(sqlSearch, function (err, result) {
    if (err) throw err;
    res.status(200).send({ searchResults: result });
  });
});

app.get('/api/getSong', async (req, res, next) => {
  const songId = req.query["id"];
  let sqlSelect = "SELECT Title FROM Recordings WHERE ID=" + songId;
  var fileName = "";

  console.log(sqlSelect);

  pool.execute(sqlSelect, function (err, result) {
    if (err) {
      console.log("Get song failed.");
      ms.pipe(req, res, './Music/' + 'default' + '.mp3');
    }
    else if (result[0]) {
      fileName = result[0].Title;
      ms.pipe(req, res, './Music/' + fileName + '.mp3');
    }
  });
});

//Servers listening
app.listen(APIPort);
socketServer.listen(socketPort, console.log("Listening"));

//Leftovers
//CREATE USER 'NewUser'@'localhost' IDENTIFIED BY '3atth!s!';
//CREATE USER 'New'@'localhost' IDENTIFIED BY 'MyN3wP4ssw0rd';